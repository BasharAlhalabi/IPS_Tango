package de.tu_chemnitz.projecttangostudy;

import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;

import com.google.atap.tango.reconstruction.Tango3dReconstruction;
import com.google.atap.tango.reconstruction.Tango3dReconstructionConfig;
import com.google.atap.tango.reconstruction.TangoPolygon;
import com.google.atap.tangoservice.Tango;
import com.google.atap.tangoservice.TangoCameraIntrinsics;
import com.google.atap.tangoservice.TangoEvent;
import com.google.atap.tangoservice.TangoPointCloudData;
import com.google.atap.tangoservice.TangoPoseData;
import com.google.atap.tangoservice.TangoXyzIjData;
import com.projecttango.tangosupport.TangoPointCloudManager;
import com.projecttango.tangosupport.TangoSupport;

import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Halabi on 12.04.2017.
 * A middleware between raw pos, rot. It does the needed calculations and provides them to the renderer
 */

public class FloorManager extends Tango.TangoUpdateCallback{

    private static final String TAG = FloorPlanNavigator.class.getSimpleName();
    private final TangoPointCloudManager mPointCloudBuffer;

    private FloorObject mFloorObject = null; //to handle events of floor change
    private _2D_RenderingView m2D_renderingView;
    private Tango3dReconstruction mTango3dReconstruction = null;
    private OnFloorPlanDataAvailableListener mFloorPlanDataAvailableCallback = null;
    private HandlerThread mHandlerThread = null;
    private volatile Handler mHandler = null;

    private volatile boolean mIsFloorplanningActive = false;

    private Runnable mRunnableCallback = null;


    /**
     * Callback for when meshes are available.
     */
    public interface OnFloorPlanDataAvailableListener {
        void onFloorPlanDataAvailable(List<TangoPolygon> polygons);
    }

    /**
     * Synchronize access to mTango3dReconstruction. This runs in UI thread.
     */
    public synchronized void release() {
        mIsFloorplanningActive = false;
        mTango3dReconstruction.release();
    }

    public void startFloorplanning() {
        mIsFloorplanningActive = true;
    }

    public void stopFloorplanning() {
        mIsFloorplanningActive = false;
    }

    /**
     * Synchronize access to mTango3dReconstruction. This runs in UI thread.
     */
    public synchronized void resetFloorplan() {
        if(mTango3dReconstruction != null)
            mTango3dReconstruction.clear();
    }



    /**
     * Synchronize access to mTango3dReconstruction. This runs in UI thread.
     */
    public synchronized void setDepthCameraCalibration(TangoCameraIntrinsics calibration) {
        mTango3dReconstruction.setDepthCameraCalibration(calibration);
    }



    public FloorManager(OnFloorPlanDataAvailableListener callback)
    {

        mFloorPlanDataAvailableCallback = callback;
        Tango3dReconstructionConfig config = new Tango3dReconstructionConfig();
        // Configure the 3D reconstruction library to work in "floorplan" mode.
        config.putBoolean("use_floorplan", true);
        config.putBoolean("generate_color", false);
        // Simplify the detected countours by allowing a maximum error of (5cm --> 1cm)
        config.putDouble("floorplan_max_error", 0.05);
        mTango3dReconstruction = new Tango3dReconstruction(config);

        mPointCloudBuffer = new TangoPointCloudManager();

        mHandlerThread = new HandlerThread("mesherCallback");
        mHandlerThread.start();
        mHandler = new Handler(mHandlerThread.getLooper());

        if (callback != null) {
            /**
             * This runnable processes the saved point clouds and meshes and triggers the
             * onFloorplanAvailable callback with the generated {@code TangoPolygon} instances.
             */
            mRunnableCallback = new Runnable() {
                @Override
                public void run() {
                    // Synchronize access to mTango3dReconstruction. This runs in FloorManager thread.
                    synchronized (FloorManager.this) {
                        if (!mIsFloorplanningActive) {
                            return;
                        }

                        if (mPointCloudBuffer.getLatestPointCloud() == null) {
                            return;
                        }

                        // Get the latest point cloud data.
                            TangoPointCloudData cloudData = mPointCloudBuffer.getLatestPointCloud();

                            TangoPoseData depthPose = null;

                        if(!FloorPlanNavigator.isDriftCorrection && !FloorPlanNavigator.isLearningMode)
                            depthPose = TangoSupport.getPoseAtTime(cloudData.timestamp,
                                    TangoPoseData.COORDINATE_FRAME_START_OF_SERVICE,
                                    TangoPoseData.COORDINATE_FRAME_CAMERA_DEPTH,
                                    TangoSupport.TANGO_SUPPORT_ENGINE_TANGO,
                                    TangoSupport.ROTATION_IGNORED);
                            else
                            depthPose = TangoSupport.getPoseAtTime(cloudData.timestamp,
                                    TangoPoseData.COORDINATE_FRAME_AREA_DESCRIPTION,
                                    TangoPoseData.COORDINATE_FRAME_CAMERA_DEPTH,
                                    TangoSupport.TANGO_SUPPORT_ENGINE_TANGO,
                                    TangoSupport.ROTATION_IGNORED);

                            if (depthPose.statusCode != TangoPoseData.POSE_VALID) {
                                Log.e(TAG, "couldn't extract a valid depth pose");
                                return;
                            }

                        // Update the mesh and floorplan representation.
                        mTango3dReconstruction.updateFloorplan(cloudData, depthPose);

                        // Extract the full set of floorplan polygons.
                        List<TangoPolygon> polygons = mTango3dReconstruction.extractFloorplan();

                        // Provide the new floorplan polygons to the app via callback.
                        mFloorPlanDataAvailableCallback.onFloorPlanDataAvailable(polygons);
                    }
                }
            };
        }

        mFloorObject = new FloorObject();
        if(FloorPlanNavigator.m2D_RenderingView != null)
            mFloorObject.addFloorSwitchListener(FloorPlanNavigator.m2D_RenderingView);
    }



    private boolean floor_switched = false;


    public void setAvailablePose(TangoPoseData pose) { //here I calculate the floor number based on Y and raise an event about floor switch

        float translation[] = pose.getTranslationAsFloats(); //Y: translation[1]
        handle_floor_switching(translation[1]);

    }



    void handle_floor_switching(float current_Y_of_camera)
    {
        double Floor_of_floor = 0.0f;

        double scale_buffer_measurement = 0.1; //10 cm

        Floor_of_floor = current_Y_of_camera - FloorPlanNavigator.estimated_height_of_persons_hands + scale_buffer_measurement; //Y=Floor of floor (m)

        floor_switched = false;
        int last_floor_num = FloorPlanNavigator.current_floor_number;

        //calculate the current floor
        if(!FloorPlanNavigator.different_floors_heights)
        {
            FloorPlanNavigator.current_floor_number = FloorPlanNavigator.start_floor_number +  (int)(Math.ceil((Floor_of_floor)/ FloorPlanNavigator.estimated_floor_height));
            //calculate rest height to switch
            FloorPlanNavigator.estimated_rest_height_to_switch = Math.abs(Floor_of_floor/ FloorPlanNavigator.estimated_floor_height);
        }
        else if(FloorPlanNavigator.current_floor_number >= 0)
        {
            FloorPlanNavigator.current_floor_number = FloorPlanNavigator.start_floor_number +  (int)(Math.ceil((Floor_of_floor)/ FloorPlanNavigator.estimated_floor_heightS[FloorPlanNavigator.current_floor_number]));
            //calculate rest height to switch
            FloorPlanNavigator.estimated_rest_height_to_switch = Math.abs(Floor_of_floor/ FloorPlanNavigator.estimated_floor_heightS[FloorPlanNavigator.current_floor_number]);
        }

        //cont.: calculate the rest height to switch
        if(FloorPlanNavigator.estimated_rest_height_to_switch > 1)
            FloorPlanNavigator.estimated_rest_height_to_switch--;
        else if(FloorPlanNavigator.estimated_rest_height_to_switch < 0)
            FloorPlanNavigator.estimated_rest_height_to_switch++;

        //check if floor is just changed
        if(last_floor_num < FloorPlanNavigator.current_floor_number) {
            floor_switched = true;
            mFloorObject.receiveSwitchedUpwards();
        }
        else if(last_floor_num > FloorPlanNavigator.current_floor_number) {
            floor_switched = true;
            mFloorObject.receiveSwitchedDownwards();
        }

        if(floor_switched)
            reset_floor_height_rt_calculating();
    }


    void reset_floor_height_rt_calculating()
    {
        //lowest_y_acc = Float.MAX_VALUE;
        //highest_y_acc = Float.MIN_VALUE;
        lowest_y = Float.MAX_VALUE;
        highest_y = Float.MIN_VALUE;
        FloorPlanNavigator.realTime_height = 0;
    }

    float lowest_y_acc = Float.MAX_VALUE; //min detected height over time
    float highest_y_acc = Float.MIN_VALUE; //max detected height over time

    static public float[] Pz = new float[2]; //max depth point (walls corner)
    static public float[] Pr1 = new float[2]; //a left point of a corner
    static public float[] Pr2 = new float[2]; //a right point of a corner
   // static public float[] Pr1_left_interpolated = new float[2];
    //static public float[] Pr2_right_interpolated = new float[2];

    static public float lowest_y = Float.MAX_VALUE; //curr min height
    static public float highest_y = Float.MIN_VALUE; //cur max height

    final float side_size_cm = 10.0f; //20.0f
    final float perpendicular_cut_to_cam_vector_m = 1.0f; //14.1421f   //0.707107f
    final float isosceles_triangle_base_m = 1.4142f; //28.284f


    //find out height
    static boolean camera_corner_pos_initialized = false;
    int Aufnahme_ctr = 0;
    static double[] hands_height_Aufnahmen = new double[20];

    double calculated_camera_height = 0.0;
    public static boolean angle_between_3p_is_right = false;
    /**
     * Calculates the average depth from a point cloud buffer.
     */
    private float calculateAveragedDepth_and_do_experiments(FloatBuffer pointCloudBuffer, int numPoints) {


        float furthest_z_general_m = Float.MIN_VALUE;
        List<Float> head_max_depth_reads_cm = new ArrayList<>();
        List<Float> left_max_depth_reads_cm = new ArrayList<>();
        List<Float> right_max_depth_reads_cm = new ArrayList<>();
        float x_of_furthest_z_general = 0;

        lowest_y = Float.MAX_VALUE;
        highest_y = Float.MIN_VALUE;
        float max_right_x = Float.MIN_VALUE;
        float max_left_x = Float.MAX_VALUE;
        float totalZ = 0;
        float averageZ = 0;

        if (numPoints != 0) {
            int numFloats = 4 * numPoints;
            for (int i = 2; i < numFloats; i = i + 4) {

                //avg calculation step 1
                totalZ = totalZ + pointCloudBuffer.get(i);

                //tests:

                // accumulative RT height calculation over time:
                if(!camera_corner_pos_initialized) {
                    if (pointCloudBuffer.get(i - 1) < lowest_y_acc) {
                        lowest_y_acc = pointCloudBuffer.get(i - 1);
                    }
                    if (pointCloudBuffer.get(i - 1) > highest_y_acc) {
                        highest_y_acc = pointCloudBuffer.get(i - 1);
                    }
                }


                //  current RT height calculation:
                if (pointCloudBuffer.get(i - 1) < lowest_y) {
                    lowest_y = pointCloudBuffer.get(i - 1);
                }
                if (pointCloudBuffer.get(i - 1) > highest_y) {
                    highest_y = pointCloudBuffer.get(i - 1);
                }

                //deepest point w.r.t camera
                if (.3 >= pointCloudBuffer.get(i - 2) && -.3 <= pointCloudBuffer.get(i - 2)) //X range to searching for max depth (middle of cam view vertically)
                    if (pointCloudBuffer.get(i) > furthest_z_general_m) {
                        furthest_z_general_m = pointCloudBuffer.get(i);
                        head_max_depth_reads_cm.add(furthest_z_general_m );
                        x_of_furthest_z_general = pointCloudBuffer.get(i - 2);
                    }
                //deepest point when x & y somehow middle of cam view
                //   if ( .5 >= pointCloudBuffer.get(i - 1) &&  -.5 <= pointCloudBuffer.get(i - 1) && 1.5 >= pointCloudBuffer.get(i - 2) && - 1.5 <= pointCloudBuffer.get(i - 2))
                    /*if (pointCloudBuffer.get(i) > furthest_z_horizontally_m) {
                        furthest_z_horizontally_m = pointCloudBuffer.get(i);
                        x_of_furthest_z_horizontally = pointCloudBuffer.get(i - 2);
                    }*/

                // if(pointCloudBuffer.get(i-2) > max_right_x_for_cam_init && FloorPlanNavigator.map_calibration_phase)
                //     max_right_x_for_cam_init = pointCloudBuffer.get(i-2); //to find 1 m along init wall


                // |_ find the corner (floor / wall) in order to find the RT height of camera
               /* if(pointCloudBuffer.get(i) > furthest_z_corner && pointCloudBuffer.get(i - 2) > -0.005 && pointCloudBuffer.get(i - 2) < 0.005) { // y- is upwards! // Z+ forwards
                    furthest_z_corner = pointCloudBuffer.get(i);

                    pos_of_point_by_furthest_z[0] = pointCloudBuffer.get(i - 2); // the direct sight at x := 0 --> line of y
                    pos_of_point_by_furthest_z[1] = pointCloudBuffer.get(i-1);
                    pos_of_point_by_furthest_z[2] = furthest_z_corner;
                }*/

            }
            averageZ = totalZ / numPoints;

            //accumulative modded max
            if(head_max_depth_reads_cm.size() > 10 && false)
            furthest_z_general_m = mode(convertIntegers(head_max_depth_reads_cm));

            //form a vertical corner between 2 walls with error range of 2 cm
            for (int i = 2; i < numFloats; i = i + 4) {

                if (pointCloudBuffer.get(i - 2) > max_right_x && (furthest_z_general_m - perpendicular_cut_to_cam_vector_m) + 0.001 >= pointCloudBuffer.get(i) && (furthest_z_general_m - perpendicular_cut_to_cam_vector_m) - 0.001 <= pointCloudBuffer.get(i))
                {
                    max_right_x = pointCloudBuffer.get(i - 2);
                    right_max_depth_reads_cm.add(max_right_x );
                }
                if (pointCloudBuffer.get(i - 2) < max_left_x && (furthest_z_general_m - perpendicular_cut_to_cam_vector_m) + 0.001 >= pointCloudBuffer.get(i) && (furthest_z_general_m - perpendicular_cut_to_cam_vector_m) - 0.001 <= pointCloudBuffer.get(i))
                {
                    max_left_x = pointCloudBuffer.get(i - 2);
                    left_max_depth_reads_cm.add(max_left_x );
                }
            }

            //accumulative modded maxes
            if(left_max_depth_reads_cm.size() > 10 && right_max_depth_reads_cm.size() > 10 && false) {
                max_left_x = mode(convertIntegers(left_max_depth_reads_cm));
                max_right_x = mode(convertIntegers(right_max_depth_reads_cm));
            }


            //deep point
            Pz[0] = x_of_furthest_z_general; //2d: x
            Pz[1] = furthest_z_general_m; //tief point //2d: y //3d: z

            //left point
            Pr1[0] = max_left_x;
            Pr1[1] = (furthest_z_general_m - perpendicular_cut_to_cam_vector_m);

            //right point
            Pr2[0] = max_right_x;
            Pr2[1] = (furthest_z_general_m - perpendicular_cut_to_cam_vector_m);

            float angle_between_3p = angle_between_3_points_wrt_first_one(Pz[0], Pz[1], Pr1[0], Pr1[1], Pr2[0], Pr2[1]);

            //check if corner makes since, with error range of 1 degree:
            if (Math.abs(angle_between_3p) > 89.5f && Math.abs(angle_between_3p) < 90.5f && furthest_z_general_m != Float.MIN_VALUE) {
                //interpolate w.r.t real scaling of 0.5 M:
                //  final float factor_to_approx_real_metre = 1f; //representation
                //  final float fixed_distance_from_corner = 0.1f; //representation
                //   Pr1_left_interpolated = FloorManager.point_on_line_with_fixed_length_from_first_point((fixed_distance_from_corner * factor_to_approx_real_metre) , Pz[0], Pz[1], Pr1[0], Pr1[1]); //triangle's edge length is approx. 0.5 (m)
                // Pr2_right_interpolated = FloorManager.point_on_line_with_fixed_length_from_first_point((fixed_distance_from_corner * factor_to_approx_real_metre) , Pz[0], Pz[1], Pr2[0], Pr2[1]); //triangle's edge length is approx. 0.5 (m)

                angle_between_3p_is_right = true;
            } else angle_between_3p_is_right = false;


            //find the direct line to wall in order to find the RT height of camera (max height of 20 results is the best answer: still not accurate! to 40 CM misscaled out of real 150CM height and 200CM distance from wall)
           /* if(!camera_corner_pos_initialized) {
                for (int i = 2; i < numFloats; i = i + 4) {

                    //y of the vertically located point at wall should be greater than the last detected point at corner <base>
                    if (pointCloudBuffer.get(i) < nearest_z_wall && pointCloudBuffer.get(i - 1) < pos_of_point_by_furthest_z[1] && pointCloudBuffer.get(i - 2) > -0.005 && pointCloudBuffer.get(i - 2) < 0.005) {
                        nearest_z_wall = pointCloudBuffer.get(i);

                        pos_of_point_by_nearest_z[0] = pointCloudBuffer.get(i - 2); //x
                        pos_of_point_by_nearest_z[1] = pointCloudBuffer.get(i - 1); //y
                        pos_of_point_by_nearest_z[2] = nearest_z_wall; //z: depth
                    }
                }

                Aufnahme_ctr++;

                if(Aufnahme_ctr == 19) {
                   // hands_height_Aufnahmen= null;
                   // camera_corner_pos_initialized = true;
                    calculated_camera_height = hands_height_Aufnahmen[Aufnahme_ctr ] = dist(pos_of_point_by_nearest_z[0], pos_of_point_by_nearest_z[1], pos_of_point_by_furthest_z[0], pos_of_point_by_furthest_z[1], pos_of_point_by_nearest_z[2], pos_of_point_by_furthest_z[2]);
                    Aufnahme_ctr = 0;
                }

            }*/

        }


        calculated_camera_height = Math.abs(lowest_y);//findMax(hands_height_Aufnahmen); //test

        FloorPlanNavigator.realTime_height = Math.abs(highest_y_acc - lowest_y_acc); // accumulative over time
        //FloorPlanNavigator.realTime_height = Math.abs(highest_y - lowest_y);
        FloorPlanNavigator.realTime_Hands_height = calculated_camera_height;//dist(pos_of_point_by_nearest_z[0], pos_of_point_by_nearest_z[1], pos_of_point_by_furthest_z[0], pos_of_point_by_furthest_z[1], pos_of_point_by_nearest_z[2], pos_of_point_by_furthest_z[2]);//Math.abs(pos_of_point_by_furthest_z[1] - pos_of_point_by_nearest_z[1]) ; //test

        return averageZ;
    }


    public static float[] convertIntegers(List<Float> integers)
    {
        Collections.reverse(integers);
        float percentage = (integers.size() * 20) / 100; //2% from total size
        int convert_from = integers.size() -(int) percentage;
        int arr_size = (int) percentage;
        float[] ret = new float[arr_size];
        for (int i= convert_from - 1; i < ret.length; i++)
        {
            ret[i] = integers.get(i);
        }
        return ret;
    }


   /* public static int mode(List<Integer> input) {

        int[] count = new int[input.size()];

        //count the occurrences
        for (int i=0; i < input.size(); i++) {
            count[input.get(i)]++;
        }

        //go backwards and find the count with the most occurrences
        int index = count.length-1;
        for (int i=count.length-2; i >=0; i--) {
            if (count[i] >= count[index])
                index = i;
        }

        return index;
    }*/


    float mode(float[] source) {
      /*  if (source.length == 0)
            return -1;
        HashMap<Float,Integer> modeMap = new HashMap<Float,Integer>();
        float result = source[0];
        int maxCount = 1;
        for (int i = 0; i < source.length; i++) {
            float el = source[i];
            if (modeMap.get(el) == null)
                modeMap.put(el,1);
            else
                modeMap.put(el,modeMap.get(el)+1);
            if (modeMap.get(el) > maxCount) {
                result = el;
                maxCount = modeMap.get(el);
            }
        }*/

        Arrays.sort(source);
        double median;
        if (source.length % 2 == 0)
            median = ((double)source[source.length/2] + (double)source[source.length/2 - 1])/2;
        else
            median = (double) source[source.length/2];
        return (float)median;

    // return  result;
    }


    static public float angle_between_3_points_wrt_first_one(float x1, float y1, float x2, float y2, float x3, float y3) {

        float teta = 0.0f;

        //Vector2 vec1 = new Vector2(x2 - x1, y2 - y1);
       // Vector2 vec2 = new Vector2(x3 - x1, y3 - y1);

        double angle1 = Math.atan2(y1 - y2, x1 - x2);
        double angle2 = Math.atan2(y1 - y3, x1 - x3);
        teta = (float) Math.toDegrees(angle1-angle2);

        return teta;
    }


    //find point on line with distance from first given point
    static public float[] point_on_line_with_length_ratio_starting_from_first_point_using_points(float length_m, float x1, float y1, float x2, float y2) {

        float[] point = new float[2];

        //length should be from 0 to 1:
        float ratio = length_m/(float) dist_m(x1, y1, x2, y2) ;

        point[0] = ratio * x1 + (1.0f - ratio) * x2;
        point[1] = ratio * y1 + (1.0f - ratio) * y2;

        return point;
    }


    //find point on line with distance from first given point
    static public float[] point_on_line_with_length_ratio_starting_from_first_point_using_vectors(float length_m, float x1, float y1, float x2, float y2) {

        float[] point = new float[2];

        Vec2D vec1 = new Vec2D(x1, y1);
        Vec2D vec2 = new Vec2D(x2, y2);
        //P = d(B - A) + A

            Vec2D vec_desired = (vec2.sub(vec1).scale(length_m)).add(vec1);
        //vec_desired.normalize();

        point[0] = (float) vec_desired.dX;
        point[1] = (float) vec_desired.dY;
        return point;
    }


    //find point on line with distance from first given point
    static public float[] point_on_line_with_fixed_length_from_first_point(float length_m, float x1, float y1, float x2, float y2) {

        float[] point = new float[2];

        point[0] = (float) (x1 + length_m * ( (x2 - x1) / (Math.sqrt( Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2) )) ));
        point[1] = (float) (y1 + length_m * ( (y2 - y1) / (Math.sqrt( Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2) )) ));
        return point;
    }

    static public double dist_m(float X1, float Y1, float X2, float Y2) {

        double distance = 0;

        float v0X = X1;
        float v1X = X2;

        float v0Y = Y1;
        float v1Y = Y2;

        distance = Math.sqrt(Math.pow((v0X-v1X), 2) + Math.pow((v0Y-v1Y), 2));

        return distance;

    }

    private double findMax(double... vals) {
        double max = Double.NEGATIVE_INFINITY;

        for (double d : vals) {
            if (d > max) max = d;
        }

        return max;
    }

    private double dist(float X1, float Y1, float X2, float Y2, float Z1, float Z2) { //m

        double distance = 0;

        float v0X = X1;
        float v1X = X2;

        float v0Y = Y1;
        float v1Y = Y2;

        float v0Z = Z1;
        float v1Z = Z2;

        distance = Math.sqrt(Math.pow((v0X-v1X), 2) + Math.pow((v0Y-v1Y), 2) + Math.pow((v0Z-v1Z), 2));

        return distance;

    }


    //Overrides:
    @Override
    public void onPoseAvailable(TangoPoseData pose) {

        //pose is taken from the listener placed in FloorPlanNavigator

        /*if (!mIsFloorplanningActive) {
            return;
        }

        //Log current pose
        logPose(pose);

        //pass pose to the renderer to handle floor-switching
        FloorPlanNavigator.m2D_RenderingView.setAvailablePose(pose);*/
    }

    @Override
    public void onXyzIjAvailable(final TangoXyzIjData var1) {
        // do nothing.
    }

    /**
     * Receives the depth point cloud. This method retrieves and stores the depth camera pose
     * and point cloud to later use it when updating the {@code Tango3dReconstruction}.
     *
     * @param tangoPointCloudData the depth point cloud.
     */
    @Override
    public void onPointCloudAvailable(final TangoPointCloudData tangoPointCloudData) {

            if (!mIsFloorplanningActive || tangoPointCloudData == null || tangoPointCloudData.points == null) {
                return;
            }

            //calculate avg depth
            final float avg_depth = calculateAveragedDepth_and_do_experiments(tangoPointCloudData.points, tangoPointCloudData.numPoints);
            //pass avg_depth to the renderer
            FloorPlanNavigator.m2D_RenderingView.set_Avg_ObjectsDepth_in_front_of_the_camera(avg_depth);

            //display the result as Text in the dirty way:
            FloorPlanNavigator.avg_depth = avg_depth;

            //log avg_depth
            if (FloorPlanNavigator.show_avg_depth_log)
                logPointCloud(avg_depth, tangoPointCloudData.numPoints);

            mPointCloudBuffer.updatePointCloud(tangoPointCloudData);

            mHandler.removeCallbacksAndMessages(null);
            mHandler.post(mRunnableCallback);

    }




    @Override
    public void onFrameAvailable(int var1) {

    }

    @Override
    public void onTangoEvent(TangoEvent var1) {

    }



    /**
     * Log the point count and the average depth of the given PointCloud data
     * in the Logcat as information.
     */
    private void logPointCloud(float avg_depth, int points_number) {

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Point count: " + points_number);
        stringBuilder.append(". Average depth (m): " + avg_depth);
        Log.i(TAG, stringBuilder.toString());

    }


    private static float[] camera_point = new float[2];
    private static final double EPSILON = 0.000001;

    private boolean calculateThreeCircleIntersection(double x0, double y0, double r0,
                                                     double x1, double y1, double r1,
                                                     double x2, double y2, double r2)
    {
        double a, dx, dy, d, h, rx, ry;
        double point2_x, point2_y;

    /* dx and dy are the vertical and horizontal distances between
    * the circle centers.
    */
        dx = x1 - x0;
        dy = y1 - y0;

    /* Determine the straight-line distance between the centers. */
        d = Math.sqrt((dy*dy) + (dx*dx));

    /* Check for solvability. */
        if (d > (r0 + r1))
        {
        /* no solution. circles do not intersect. */
            return false;
        }
        if (d < Math.abs(r0 - r1))
        {
        /* no solution. one circle is contained in the other */
            return false;
        }

    /* 'point 2' is the point where the line through the circle
    * intersection points crosses the line between the circle
    * centers.
    */

    /* Determine the distance from point 0 to point 2. */
        a = ((r0*r0) - (r1*r1) + (d*d)) / (2.0 * d) ;

    /* Determine the coordinates of point 2. */
        point2_x = x0 + (dx * a/d);
        point2_y = y0 + (dy * a/d);

    /* Determine the distance from point 2 to either of the
    * intersection points.
    */
        h = Math.sqrt((r0*r0) - (a*a));

    /* Now determine the offsets of the intersection points from
    * point 2.
    */
        rx = -dy * (h/d);
        ry = dx * (h/d);

    /* Determine the absolute intersection points. */
        double intersectionPoint1_x = point2_x + rx;
        double intersectionPoint2_x = point2_x - rx;
        double intersectionPoint1_y = point2_y + ry;
        double intersectionPoint2_y = point2_y - ry;

        Log.d("INTERSECTION C1 AND C2:", "(" + intersectionPoint1_x + "," + intersectionPoint1_y + ")" + " AND (" + intersectionPoint2_x + "," + intersectionPoint2_y + ")");

    /* Lets determine if circle 3 intersects at either of the above intersection points. */
        dx = intersectionPoint1_x - x2;
        dy = intersectionPoint1_y - y2;
        double d1 = Math.sqrt((dy*dy) + (dx*dx));

        dx = intersectionPoint2_x - x2;
        dy = intersectionPoint2_y - y2;
        double d2 = Math.sqrt((dy*dy) + (dx*dx));

        if(Math.abs(d1 - r2) < EPSILON) {
            Log.d("INTERSECTION C1,C2,C3:", "(" + intersectionPoint1_x + "," + intersectionPoint1_y + ")");
            camera_point[0] = (float)intersectionPoint1_x;
            camera_point[1] = (float)intersectionPoint1_y;
        }
        else if(Math.abs(d2 - r2) < EPSILON) {
            Log.d("INTERSECTION C1,C2,C3:", "(" + intersectionPoint2_x + "," + intersectionPoint2_y + ")");

            camera_point[0] = (float)intersectionPoint2_x;
            camera_point[1] = (float)intersectionPoint2_y;
        }
        else {
            Log.d("INTERSECTION C1,C2,C3:", "NONE");
            camera_point[0] = (float) Double.MAX_VALUE;
            camera_point[1] = (float) Double.MAX_VALUE;
        }

        return true;
    }




}
